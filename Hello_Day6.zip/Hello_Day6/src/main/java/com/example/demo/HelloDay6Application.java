package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloDay6Application {

	public static void main(String[] args) {
		SpringApplication.run(HelloDay6Application.class, args);
	}

}
